#include <stdio.h>

int main()
{
    int firstNumber = 5;
    int secondNumber = 5;
    if (firstNumber == secondNumber) {
        printf("They are equal");
    }
    else {
        printf("They are not equal");
    }
    return 0;
}